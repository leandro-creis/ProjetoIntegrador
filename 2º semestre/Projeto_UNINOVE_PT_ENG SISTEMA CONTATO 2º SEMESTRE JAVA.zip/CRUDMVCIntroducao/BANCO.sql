CREATE TABLE contato(
    id          INT         NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome        VARCHAR(50) NOT NULL,
    email       VARCHAR(50) NOT NULL,
    telefone    VARCHAR(15) NOT NULL,
    cep           VARCHAR(12) NOT NULL



);

INSERT INTO contato (nome,email,telefone,cep)  VALUES ("REIS","lele","484848","81484");
