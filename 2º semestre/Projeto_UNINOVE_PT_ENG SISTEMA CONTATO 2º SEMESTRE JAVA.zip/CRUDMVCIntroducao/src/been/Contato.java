package been;

/**
 * @file Contato.java
 * @brief Classe para objetos do tipo Contato.
 * @brief Onde serão contidos, valores e métodos para o mesmo.
 * @author Leandro Cardoso
 * @date 09/11/2018, 11:40
 */
public class Contato {

    private int id;
    private String nome;
    private String email;
    private String telefone;
    private String cep;

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
