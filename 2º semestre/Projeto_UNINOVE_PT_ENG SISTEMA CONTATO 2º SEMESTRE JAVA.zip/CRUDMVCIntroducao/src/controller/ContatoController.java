package controller;

import been.Contato;
import java.sql.SQLException;
import java.util.List;
import model.ContatoModel;

/**
 * @file ContatoController .java
 * @brief Esta classe representa um objeto ContatoController
 * @brief Esta classe é usada para criar o metodos para minimizando o número de
 * linhas
 * @brief O controller recebe os dados e redireciona o usuário para uma view.
 * @author Leandro Cardoso
 * @date 09/11/2018, 11:40
 */
public class ContatoController {

    ContatoModel cm;
    Contato c;

    public ContatoController() throws SQLException {
        cm = new ContatoModel();
    }

    // Metodo inserir.
    public void inserir(Contato c) throws SQLException {

        cm.insert(c);
    }

    // Metodo listar
    public List<Contato> listar() throws SQLException {

        return cm.listAll();
    }

    // Metodo Pesquisar
    public List<Contato> pesquisar(Contato c) throws SQLException {
        String desc = new String();
        return cm.find(desc);

    }

    // Metodo Atualizar
    public void atualizar(Contato c) throws SQLException {

        cm.update(c);
    }

    // Metodo Excluir
    public void excluir(Contato c) throws SQLException {

        cm.delete(c);
    }

}
