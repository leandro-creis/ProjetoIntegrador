package crudmvcintroducao;

import java.sql.SQLException;
import view.Tela;

/**
 * @file CRUDMVCIntroducao.java
 * @brief Esta classe Principal do projeto.
 * @brief Está clase que determina o ponto de início de execução de qualquer aplicação.
 * @author Leandro Cardoso
 * @date 09/11/2018, 11:40
 */

public class CRUDMVCIntroducao {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {

        //Cria uma instância da classe Tela2
        Tela t2 = new Tela();

        //Seta a tela2 como visiel
        t2.setVisible(true);
    }
}
