package model;

import been.Contato;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import utils.ConnectionFactory;

/**
 * @file ContatoModel.java
 * @brief Classe que representa ContatoModel Está classe provê uma interface que abstrai o acesso a dados; lê e grava a partir da origem de dados.
 * @author Leandro Cardoso
 * @date 09/11/2018, 11:40
 */

public class ContatoModel {

    private Connection conexao;

    /**
     * This class is a conection
     *
     * @throws java.sql.SQLException
     */
    public ContatoModel() throws SQLException {
        this.conexao = ConnectionFactory.getInstance().getConnection();
    }

    /*
    * Metódo Insert. Onde os dados serão inseridos no banco de dados
     */
    public void insert(Contato c) throws SQLException {

        String sql = "INSERT INTO  "
                + "contato (nome, email, telefone, cep) VALUES (?,?,?,?)";

        //  PREParedStatement uma forma de você fazer uma inserção no banco mais segura, onde você prepara os parametros para serem inseridos.Ele desconsidera // -- # no comando. Evitando assim ataques como o sql injection. 
        try (PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, c.getNome());
            ps.setString(2, c.getEmail());
            ps.setString(3, c.getTelefone());
            ps.setString(4, c.getCep());

            // Executar o Prepared Statement
            ps.execute();

            // Fechar O Prepared Statement
            ps.close();

            // Fecha a conexão
            conexao.close();

            // Mensagem de resultado.
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Cadastrar: " + ex);
        }
    }

    /*
     Metódo Listar. Onde todos os dados que está armazenado no banco de dados será listados.
     */
    public List<Contato> listAll() throws SQLException {

        // cria um arraylist para inserir o resultado do banco de dados
        ArrayList<Contato> resultado = new ArrayList();

        String sql = "SELECT * FROM contato ORDER BY nome ASC";

        /*  PREParedStatement uma forma de você fazer uma inserção no banco mais segura,
        onde você prepara os parametros para serem inseridos.
        Ele desconsidera // -- # no comando. Evitando assim ataques como o sql injection. */
        PreparedStatement ps = conexao.prepareStatement(sql);

        /* 
            ResultSet: Ele é apenas uma tabela de dados que representa um conjunto de dados do BD.
            Para obter um ResultSet com os dados do BD é necessário utilizar ele em conjunto com 
            Connection e PreparedStatement (ou Statement).
            EXECUTEQUERY APENAS NA PESQUISA
            EXECUTEQUERY NÃO PODE SER USASO PARA ATUALIZAÇÂO OU EXCLUSAO
         */
        ResultSet rs = ps.executeQuery();

        // Enquanto tiver dados leia.
        while (rs.next()) {
            Contato c = new Contato();
            c.setId(rs.getInt("id"));
            c.setNome(rs.getString("nome"));
            c.setEmail(rs.getString("email"));
            c.setTelefone(rs.getString("telefone"));
            c.setCep(rs.getString("cep"));

            // Irar inserir os dados na ArrayList
            resultado.add(c);
        }
        // Apos a inserção. Os dados Serão retornados.
        return resultado;
    }

    /*
     Metódo Pesquisar, pesquisar registro que está no banco de dados
     */
    public List<Contato> find(String desc) throws SQLException {

        // cria um arraylist para inserir o resultado do banco de dados
        ArrayList<Contato> resultado = new ArrayList();
        String sql = "SELECT * FROM contato WHERE nome LIKE ? ORDER BY nome";

        /*  PREParedStatement uma forma de você fazer uma inserção no banco mais segura,
        onde você prepara os parametros para serem inseridos.
        Ele desconsidera // -- # no comando. Evitando assim ataques como o sql injection. */
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, "%" + desc + "%");

        /* 
            EXECUTEQUERY APENAS NA PESQUISA
            EXECUTEQUERY NÃO PODE SER USASO PARA ATUALIZAÇÂO OU EXCLUSAO
         */
        ResultSet rs = ps.executeQuery();

        Contato c = new Contato();
        while (rs.next()) {
            c = new Contato();
            c.setId(rs.getInt("id"));
            c.setNome(rs.getString("nome"));
            c.setEmail(rs.getString("email"));
            c.setTelefone(rs.getString("telefone"));
            c.setCep(rs.getString("cep"));

            // Irar inserir os dados na ArrayList
            resultado.add(c);
        }
        // Apos a inserção. Os dados Serão retornados.
        return resultado;
    }

    /*
    Atualizar um registro no banco de dados
     */
    public void update(Contato c) throws SQLException {
        try {
            String sql = "UPDATE contato SET nome = ?, email = ? , telefone = ?, cep = ? WHERE id = ?";

            /*  PREParedStatement uma forma de você fazer uma inserção no banco mais segura,
        onde você prepara os parametros para serem inseridos.
        Ele desconsidera // -- # no comando. Evitando assim ataques como o sql injection. */
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setString(1, c.getNome());
            ps.setString(2, c.getEmail());
            ps.setString(3, c.getTelefone());
            ps.setString(4, c.getCep());
            ps.setInt(5, c.getId());

            /*
                Excutar PreparedStatement
                ExecuteUpdate é usado apenas para realizar atualizações
             */
            ps.executeUpdate();

            // Fechar COnexão
            conexao.close();

            // Mensagens de Resultados.
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        }
    }

    /*
    Deletar registro do banco de Dados
     */
    public void delete(Contato c) throws SQLException {
        try {

            String sql = "DELETE FROM contato WHERE id = ?";

            /*  PREParedStatement uma forma de você fazer uma inserção no banco mais segura,
        onde você prepara os parametros para serem inseridos.
        Ele desconsidera // -- # no comando. Evitando assim ataques como o sql injection. */
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, c.getId());

            // Executar PreparedStatement
            ps.execute();
            // Fechar PreparedStatement
            ps.close();

            // Fechar Conexão
            conexao.close();

            // Mensagens de Resultado.
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        }
    }

}
